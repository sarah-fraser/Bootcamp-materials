### v1.1 | 04.19.17

_Editor: Sam Stack_

- Removed 'pytest' library as its an unnecessary import.
- Added information about currents uses of string library.
- Included additional information about 'assert' statement.
- Re-worder question 3, 5 & 6, included solution code comments.
- Added to .gitignore "DS.Store" & "*ipynb_checkpoints"

### v1.0 | 02.27.17

_Editor: Kiefer Katovich_

- Formatted notebook for DSI v2

---

### v0.0

_Author: Dave Yerrington_
