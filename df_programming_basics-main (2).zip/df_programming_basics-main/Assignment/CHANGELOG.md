### v1.1 | 04.20.17

_Editor: Sam Stack_

- commented challenge code.
- Added to .gitignore "DS.Store" & "*ipynb_checkpoints"  



### v1.0 | 02.27.17

_Editor: Kiefer Katovich_

- Formatted notebook for DSI v2

---

### v0.0

_Author: Kiefer Katovich_
